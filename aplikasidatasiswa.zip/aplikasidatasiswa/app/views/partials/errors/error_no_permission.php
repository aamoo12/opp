<div class="container">
	<div class="card-body">
		<h3 class="text-danger">Unknown user role</h3>
		<div class="text-muted"><i>Please meet the system administrator for more information!</i></div>
		<hr />
		<div class="">
			<a href="<?php print_link(HOME_PAGE); ?>" class="btn btn-primary">Go to home page</a>
		</div>
	</div>
</div>