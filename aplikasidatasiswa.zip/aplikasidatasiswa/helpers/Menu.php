<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbartopleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => ''
		),
		
		array(
			'path' => 'data_siswa', 
			'label' => 'Data Siswa', 
			'icon' => ''
		)
	);
		
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => ''
		),
		
		array(
			'path' => 'data_siswa', 
			'label' => 'Data Siswa', 
			'icon' => ''
		)
	);
		
	
	
}